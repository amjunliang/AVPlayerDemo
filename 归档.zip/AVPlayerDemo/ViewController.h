//
//  ZYMediaPlayView.m
//  AVPlayerDemo
//
//  Created by MaJunliang on 2019/9/11.
//  Copyright © 2019 yiban. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
