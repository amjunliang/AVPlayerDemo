//
//  ZYWeakTarget.h
//  AVPlayerDemo
//
//  Created by MaJunliang on 2019/9/12.
//  Copyright © 2019 yiban. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZYWeakTarget : NSObject
+ (instancetype)weakTarget:(id)target;
@end

NS_ASSUME_NONNULL_END
