### AVPlayerDemo
A simple player use AVPlayer.